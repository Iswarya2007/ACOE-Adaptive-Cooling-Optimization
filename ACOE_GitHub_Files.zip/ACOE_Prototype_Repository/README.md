# ACOE — Adaptive Cooling Optimization Engine

**AI-driven decision support for predictive and resource-aware data-center cooling.**

This educational prototype demonstrates a workflow that analyzes workload, rack temperature, and cooling indicators to estimate near-future temperatures, flag possible hotspots, and recommend actions.

> **Prototype status:** Uses synthetic sample data. It is not connected to real data-center equipment and must not control cooling hardware. Results are illustrative and do not prove real-world energy or water savings.

## Quick start
Requires Python 3.9+.

```bash
python -m pip install -r requirements.txt
python -m acoe.app --input data/sample_data.csv --output output/recommendations.csv
```

## Workflow
1. Validate workload, temperature, and cooling data.
2. Estimate the next temperature from the latest observed temperature trend.
3. Flag possible hotspots.
4. Suggest a cooling response.
5. Export results to CSV.

## Team
- Iswarya R
- Atchaya S

Sri Sairam Engineering College — Team MAVRICKS

## Structure
- `acoe/app.py` — demo analysis code
- `data/sample_data.csv` — synthetic sample dataset
- `docs/architecture.md` — architecture and limitations
- `docs/demo_script.md` — short demo script
- `tests/test_app.py` — basic tests

## Run tests
```bash
python -m unittest discover -s tests -v
```
