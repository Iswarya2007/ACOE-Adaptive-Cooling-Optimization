import argparse
from pathlib import Path
import pandas as pd

REQUIRED = {"timestamp", "rack_id", "workload_pct", "temperature_c", "cooling_power_kw", "water_lph"}

def analyze_data(df, hotspot_threshold=27.0):
    missing = REQUIRED - set(df.columns)
    if missing:
        raise ValueError("Missing required columns: " + ", ".join(sorted(missing)))
    if df.empty:
        raise ValueError("Input dataset is empty.")
    df = df.copy()
    df["timestamp"] = pd.to_datetime(df["timestamp"], errors="coerce")
    if df["timestamp"].isna().any():
        raise ValueError("Invalid timestamp found.")
    for col in ["workload_pct", "temperature_c", "cooling_power_kw", "water_lph"]:
        df[col] = pd.to_numeric(df[col], errors="coerce")
        if df[col].isna().any():
            raise ValueError(f"Missing or non-numeric values in {col}.")
    if not df["workload_pct"].between(0, 100).all():
        raise ValueError("workload_pct must be between 0 and 100.")

    output = []
    for rack_id, group in df.sort_values("timestamp").groupby("rack_id"):
        group = group.sort_values("timestamp")
        latest = group.iloc[-1]
        prev = group.iloc[-2]["temperature_c"] if len(group) > 1 else latest["temperature_c"]
        trend = float(latest["temperature_c"] - prev)
        predicted = float(latest["temperature_c"] + trend)
        hotspot = predicted >= hotspot_threshold or trend >= 2.0
        if hotspot:
            action = "Increase cooling and inspect rack airflow"
        elif latest["workload_pct"] >= 80:
            action = "Prepare preventive cooling; monitor closely"
        else:
            action = "Maintain current cooling and continue monitoring"
        output.append({
            "timestamp": latest["timestamp"].isoformat(),
            "rack_id": str(rack_id),
            "workload_pct": float(latest["workload_pct"]),
            "current_temperature_c": float(latest["temperature_c"]),
            "temperature_trend_c_per_step": trend,
            "predicted_next_temperature_c": round(predicted, 2),
            "potential_hotspot": bool(hotspot),
            "recommended_action": action,
            "cooling_power_kw": float(latest["cooling_power_kw"]),
            "water_lph": float(latest["water_lph"]),
            "note": "Illustrative estimate; validate before operational use"
        })
    return pd.DataFrame(output)

def main():
    parser = argparse.ArgumentParser(description="Run the ACOE demo.")
    parser.add_argument("--input", default="data/sample_data.csv")
    parser.add_argument("--output", default="output/recommendations.csv")
    args = parser.parse_args()
    result = analyze_data(pd.read_csv(args.input))
    output = Path(args.output)
    output.parent.mkdir(parents=True, exist_ok=True)
    result.to_csv(output, index=False)
    print(result[["rack_id", "predicted_next_temperature_c", "potential_hotspot", "recommended_action"]].to_string(index=False))
    print(f"Saved results to {output}")

if __name__ == "__main__":
    main()
