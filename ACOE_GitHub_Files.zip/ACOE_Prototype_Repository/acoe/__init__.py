"""ACOE prototype package."""
