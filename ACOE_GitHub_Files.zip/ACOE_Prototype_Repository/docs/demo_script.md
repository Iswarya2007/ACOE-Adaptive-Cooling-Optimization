# Three-minute demo

1. Explain the problem: data-center workloads change and heat can be uneven across racks.
2. Show `data/sample_data.csv`.
3. Run: `python -m acoe.app --input data/sample_data.csv --output output/recommendations.csv`
4. Open the generated CSV and explain predicted temperature, hotspot flag, and suggested action.
5. Clarify that this is a synthetic-data prototype; it does not demonstrate measured savings.
6. Describe next steps: validate on approved real data, measure forecasting accuracy, and build a dashboard.
