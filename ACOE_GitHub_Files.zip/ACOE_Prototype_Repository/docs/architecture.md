# ACOE Architecture

```text
Workload + Temperature + Cooling Data
                 |
                 v
       Validation / Preprocessing
                 |
                 v
        Temperature Trend Estimate
                 |
                 v
         Hotspot Risk Heuristic
                 |
                 v
        Cooling Recommendation
                 |
                 v
           CSV Report
```

## Limitations
- The included dataset is synthetic.
- The 27°C threshold is a demo value, not a universal safety standard.
- Temperature prediction is a simple trend heuristic, not a validated ML model.
- Resource columns are sample indicators; the prototype does not claim measured savings.
- No real-time connection or hardware control is implemented.
- Real deployment requires site-specific validation, operator review, fail-safe controls, and security assessment.
