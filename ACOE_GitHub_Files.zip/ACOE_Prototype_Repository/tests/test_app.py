import sys
import unittest
from pathlib import Path
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from acoe.app import analyze_data

class TestACOE(unittest.TestCase):
    def test_hotspot_detected(self):
        df = pd.DataFrame([
            {"timestamp":"2026-10-27T10:00:00","rack_id":"A","workload_pct":70,"temperature_c":25.0,"cooling_power_kw":4.0,"water_lph":18},
            {"timestamp":"2026-10-27T10:05:00","rack_id":"A","workload_pct":85,"temperature_c":28.0,"cooling_power_kw":4.5,"water_lph":20},
        ])
        self.assertTrue(bool(analyze_data(df).iloc[0]["potential_hotspot"]))

    def test_missing_column(self):
        with self.assertRaises(ValueError):
            analyze_data(pd.DataFrame([{"rack_id":"A"}]))

if __name__ == "__main__":
    unittest.main()
